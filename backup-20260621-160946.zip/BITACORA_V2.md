
#### [ARQUITECTO] � 2026-06-21 � Correcciones finales de inscripci�n y panel

**Decisi�n/Lecci�n Clave:**
> La disponibilidad deb�a considerar por separado instructores y motos seg�n si el estudiante trae o no su propia moto. Centralizar la l�gica en una funci�n pura (calcularDisponibilidadBloque) y separar el c�lculo de d�as (sin locks) del de bloques (con locks) resolvi� m�ltiples bugs.

**Contexto:**
> La sesi�n fue extremadamente dif�cil. Se reintrodujo el bug del campo ctivo/ctiva, se rompi� la cinta de fechas al cambiar de d�a, y el panel del estudiante fall� por un error en el orden de los hooks. Se corrigi� cada bug con verificaci�n en vivo.

**Alternativas Consideradas:**
> - Modificar el formulario de motos para usar el campo ctiva ? Rechazado por impacto en datos existentes.
> - Usar disabled en los botones de fecha ? Rechazado porque bloquea el evento onClick.
> - Minuto de gracia autom�tico ? Rechazado por el Operador; se implement� modal con l�mite de 3 intentos.

**Impacto y Deuda:**
> Se cerraron 8 bugs. Se document� el campo ctivo con un comentario en el c�digo. La deuda t�cnica B66, B106 y B109 sigue pendiente.

#### [ARQUITECTO] � 2026-06-21 � Correcciones finales de inscripci�n y panel

**Decisi�n/Lecci�n Clave:**
> La disponibilidad deb�a considerar por separado instructores y motos seg�n si el estudiante trae o no su propia moto. Centralizar la l�gica en una funci�n pura (calcularDisponibilidadBloque) y separar el c�lculo de d�as (sin locks) del de bloques (con locks) resolvi� m�ltiples bugs.

**Contexto:**
> La sesi�n fue extremadamente dif�cil. Se reintrodujo el bug del campo ctivo/ctiva, se rompi� la cinta de fechas al cambiar de d�a, y el panel del estudiante fall� por un error en el orden de los hooks. Se corrigi� cada bug con verificaci�n en vivo.

**Alternativas Consideradas:**
> - Modificar el formulario de motos para usar el campo ctiva ? Rechazado por impacto en datos existentes.
> - Usar disabled en los botones de fecha ? Rechazado porque bloquea el evento onClick.
> - Minuto de gracia autom�tico ? Rechazado por el Operador; se implement� modal con l�mite de 3 intentos.

**Impacto y Deuda:**
> Se cerraron 8 bugs. Se document� el campo ctivo con un comentario en el c�digo. La deuda t�cnica B66, B106 y B109 sigue pendiente.

#### [ARQUITECTO] � 2026-06-21 � Correcciones finales de inscripci�n y panel

**Decisi�n/Lecci�n Clave:**
> La disponibilidad deb�a considerar por separado instructores y motos seg�n si el estudiante trae o no su propia moto. Centralizar la l�gica en una funci�n pura (calcularDisponibilidadBloque) y separar el c�lculo de d�as (sin locks) del de bloques (con locks) resolvi� m�ltiples bugs.

**Contexto:**
> La sesi�n fue extremadamente dif�cil. Se reintrodujo el bug del campo ctivo/ctiva, se rompi� la cinta de fechas al cambiar de d�a, y el panel del estudiante fall� por un error en el orden de los hooks. Se corrigi� cada bug con verificaci�n en vivo.

**Alternativas Consideradas:**
> - Modificar el formulario de motos para usar el campo ctiva ? Rechazado por impacto en datos existentes.
> - Usar disabled en los botones de fecha ? Rechazado porque bloquea el evento onClick.
> - Minuto de gracia autom�tico ? Rechazado por el Operador; se implement� modal con l�mite de 3 intentos.

**Impacto y Deuda:**
> Se cerraron 8 bugs. Se document� el campo ctivo con un comentario en el c�digo. La deuda t�cnica B66, B106 y B109 sigue pendiente.
