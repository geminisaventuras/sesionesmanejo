
## Decisiones recientes (20/06/2026)
- Compactaci�n de m�rgenes en paso 1 (gap-2, mb-0.5) para ganar espacio vertical.
- Selector de fecha de nacimiento con tres ruedas (d�a/mes/a�o) usando ResizeObserver y medici�n real de posiciones de elementos.
- Formulario de salud obligatorio como modal, con pregunta de condici�n m�dica y detalle condicional.
- Stepper con c�rculos navegables hacia pasos ya completados.
- Paso 3 unificado con dise�o azul, cinta de fechas din�mica centrada en la fecha seleccionada.
- Paso 4 con desglose de precios en factura, iconos en acorde�n de pago m�vil, captcha junto a referencia, reloj de cuenta regresiva dentro de la tarjeta.
- Correo electr�nico y contacto de emergencia a�adidos al paso 1.

## Modo de ejecuci�n
MVP Simplificado (seg�n Super Marco de Trabajo V6.3).

## Decisiones del 20/06/2026 (segunda sesi�n)
- Login unificado con pesta�as Estudiante (correo+PIN) y Staff (email+clave+Google).
- Registro de estudiantes con correo real en lugar de correo sint�tico.
- Reconocimiento del rol de administrador desde la colecci�n dmins en Firestore.
- Persistencia offline de Firestore (enableIndexedDbPersistence) para evitar reinicio de tasas.
- Reglas de seguridad de Firestore actualizadas: acceso restringido por rol (admin/instructor/estudiante).
- Copia de datos de pago m�vil al portapapeles con c�digo del banco.
- Ajustes visuales en el paso 3 (bot�n "Ver calendario completo" con iconos) y paso 4 (reloj dentro de la tarjeta de pago).
