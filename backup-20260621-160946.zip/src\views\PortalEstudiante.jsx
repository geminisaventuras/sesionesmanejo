// @build: 2026-06-18.06-30-00 | id: SISTEMA | desc: Botón primary y sin título duplicado
import { useState, useContext, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import { AppContext } from '../context/AppContextValue';
import { useToast } from '../modules/shared/components/ToastProvider';
import AppShell from '../modules/shared/components/AppShell';
import { Button, Input } from '../components/UI';
import { ChevronLeft, Hash, Key, Clock } from 'lucide-react';

const MAX_INTENTOS = 3;
const TIEMPO_BLOQUEO = 15 * 60 * 1000;

export const PortalEstudiante = () => {
  const { loginEstudiante, setUser } = useContext(AppContext);
  const { showToast } = useToast();
  const navigate = useNavigate();
  const [cedula, setCedula] = useState('');
  const [pin, setPin] = useState('');
  const [cargando, setCargando] = useState(false);
  const [bloqueado, setBloqueado] = useState(false);
  const [tiempoRestante, setTiempoRestante] = useState(0);

  useEffect(() => {
    const bloqueoHasta = localStorage.getItem('login_bloqueo_hasta');
    if (bloqueoHasta) {
      const restante = parseInt(bloqueoHasta) - Date.now();
      if (restante > 0) { setBloqueado(true); setTiempoRestante(restante); }
      else { localStorage.removeItem('login_bloqueo_hasta'); localStorage.removeItem('login_intentos'); }
    }
  }, []);

  useEffect(() => {
    if (!bloqueado) return;
    const timer = setInterval(() => {
      const restante = parseInt(localStorage.getItem('login_bloqueo_hasta')) - Date.now();
      if (restante <= 0) { clearInterval(timer); setBloqueado(false); localStorage.removeItem('login_bloqueo_hasta'); localStorage.removeItem('login_intentos'); }
      else setTiempoRestante(restante);
    }, 1000);
    return () => clearInterval(timer);
  }, [bloqueado]);

  const formatTiempo = (ms) => {
    const mins = Math.floor(ms / 60000);
    const secs = Math.floor((ms % 60000) / 1000);
    return `${mins.toString().padStart(2, '0')}:${secs.toString().padStart(2, '0')}`;
  };

  const handleLogin = async (e) => {
    e.preventDefault();
    if (bloqueado) return;
    setCargando(true);
    const result = await loginEstudiante(cedula, pin);
    setCargando(false);
    if (result.success) {
      localStorage.removeItem('login_intentos'); localStorage.removeItem('login_bloqueo_hasta');
      setUser({ role: 'estudiante', data: { cedula }, uid: result.data.user.uid });
      navigate('/portal-reservas');
    } else {
      const intentos = parseInt(localStorage.getItem('login_intentos') || '0') + 1;
      localStorage.setItem('login_intentos', intentos.toString());
      if (intentos >= MAX_INTENTOS) {
        const bloqueoHasta = Date.now() + TIEMPO_BLOQUEO;
        localStorage.setItem('login_bloqueo_hasta', bloqueoHasta.toString());
        setBloqueado(true); setTiempoRestante(TIEMPO_BLOQUEO);
        showToast('Demasiados intentos. Bloqueado por 15 minutos.', 'error');
      } else {
        showToast(`PIN incorrecto. Intentos restantes: ${MAX_INTENTOS - intentos}`, 'error');
      }
    }
  };

  const header = (
    <div className="bg-white border-b px-5 py-3 flex items-center gap-3">
      <button onClick={() => navigate('/')} className="p-2 bg-gray-100 rounded-full">
        <ChevronLeft size={24} />
      </button>
      <h2 className="text-xl font-black uppercase flex-1">Portal Estudiante</h2>
    </div>
  );

  return (
    <AppShell header={header} bgColor="bg-white">
      <div className="p-6 flex flex-col justify-center min-h-full">
        <div className="w-20 h-20 bg-blue-100 rounded-3xl flex items-center justify-center mb-6 mx-auto">
          <Hash size={36} className="text-blue-600" />
        </div>
        <p className="text-center text-gray-500 text-sm mb-8">
          Ingresa tu cédula y PIN para acceder a tu panel.
        </p>
        {bloqueado ? (
          <div className="text-center bg-red-50 border border-red-200 p-4 rounded-xl">
            <Clock size={24} className="text-red-700 mx-auto mb-2" />
            <p className="font-bold text-red-700">Acceso bloqueado</p>
            <p className="text-sm text-red-600">Demasiados intentos. Tiempo restante: {formatTiempo(tiempoRestante)}</p>
          </div>
        ) : (
          <form onSubmit={handleLogin} className="space-y-4">
            <Input label="Cédula" type="tel" icon={Hash} value={cedula} onChange={e => setCedula(e.target.value.replace(/\D/g, ''))} required />
            <Input label="PIN de 6 dígitos" type="password" icon={Key} value={pin} onChange={e => setPin(e.target.value.replace(/\D/g, '').slice(0, 6))} required />
            <Button type="submit" variant="primary" disabled={cargando}>{cargando ? 'Verificando...' : 'Entrar'}</Button>
          </form>
        )}
      </div>
    </AppShell>
  );
};
